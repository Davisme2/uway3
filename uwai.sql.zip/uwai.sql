-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 04 nov. 2021 à 11:12
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `uwai`
--

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) CHARACTER SET utf8 NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8 NOT NULL,
  `prenom` varchar(255) CHARACTER SET utf8 NOT NULL,
  `sexe` int(11) NOT NULL,
  `mail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `pass` text CHARACTER SET utf8 NOT NULL,
  `n_password` int(1) NOT NULL DEFAULT '0',
  `avatar` text,
  `date_naissance` date NOT NULL,
  `region` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ville` varchar(255) CHARACTER SET utf8 NOT NULL,
  `date_inscription` datetime NOT NULL,
  `status` int(2) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `pseudo`, `nom`, `prenom`, `sexe`, `mail`, `pass`, `n_password`, `avatar`, `date_naissance`, `region`, `ville`, `date_inscription`, `status`, `role`) VALUES
(1, 'Helios64', 'Mangl&eacute;', 'David', 0, 'davis93m@gmail.com', '$6$rounds=5000$ksdjkjhsdn543jhg$1cCf/6svop1TvZx6D.UYiNPuLvVYIlHPHr6tZR7HlGiUnDvz.1KTViLkaDsNp30/qcr6o5emjPeKphlYHUo.M1', 0, '3cf3b174b488bb72e2e85bc1cd317845.jpg', '1993-07-22', 'Abidjan', 'Abidjan', '2021-10-01 13:30:07', NULL, NULL),
(2, 'banana32', 'Toto', 'toto', 0, 'toto@gmail.com', '$6$rounds=5000$ksdjkjhsdn543jhg$/7NJIUlezZ8NmgdSdsVRMsnpZ4a4fVtklY7.Yhbne9wO6t0dUm.x8FrPNk/qvVjWqRt8T2J1MIOvt1X3ubxVU.', 0, NULL, '1988-04-11', 'Gu&eacute;mon', 'Man', '2021-10-06 00:06:20', NULL, NULL),
(3, 'tito', 'TITI', 'titi', 0, 'titi@gmail.com', '$6$rounds=5000$ksdjkjhsdn543jhg$/7NJIUlezZ8NmgdSdsVRMsnpZ4a4fVtklY7.Yhbne9wO6t0dUm.x8FrPNk/qvVjWqRt8T2J1MIOvt1X3ubxVU.', 0, NULL, '1985-10-16', 'Hambol', 'Adzop&eacute;', '2021-10-06 00:08:36', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
